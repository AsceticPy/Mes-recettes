#!/usr/bin/env python3
"""
Script de test rapide pour vérifier le scraper
"""

from recipe_scraper import RecipeScraper
import json

def test_single_recipe():
    """Test avec une seule recette"""
    print("🧪 Test de récupération d'une recette aléatoire...\n")
    
    scraper = RecipeScraper()
    
    # Récupérer une recette
    meal = scraper.fetch_random_recipe()
    
    if not meal:
        print("❌ Échec de la récupération")
        return
    
    print(f"✅ Recette récupérée: {meal['strMeal']}")
    print(f"   Catégorie: {meal['strCategory']}")
    print(f"   Origine: {meal['strArea']}")
    print()
    
    # Transformer
    print("🔄 Transformation en cours...\n")
    recipe = scraper.transform_recipe(meal)
    
    # Afficher le résultat
    print("📋 Recette transformée:")
    print(json.dumps(recipe, ensure_ascii=False, indent=2))
    
    # Sauvegarder
    scraper.save_to_json([recipe], 'test_recette.json')
    print("\n✨ Test terminé avec succès !")

if __name__ == "__main__":
    test_single_recipe()

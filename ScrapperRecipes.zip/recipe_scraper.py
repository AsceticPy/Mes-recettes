#!/usr/bin/env python3
"""
Script pour récupérer des recettes depuis TheMealDB, les traduire en français
et les transformer au format JSON souhaité.

Usage:
    python recipe_scraper.py --count 10 --output recettes_fr.json
"""

import requests
import json
import time
import re
import argparse
from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class RecipeConfig:
    """Configuration pour le scraping de recettes"""
    api_base_url: str = "https://www.themealdb.com/api/json/v1/1"
    # Utilisation de LibreTranslate (API gratuite) - vous pouvez la remplacer
    translate_api: str = "https://libretranslate.com/translate"
    delay_between_requests: float = 1.0  # Délai entre les requêtes (en secondes)


class RecipeScraper:
    """Classe pour scraper et transformer les recettes de TheMealDB"""
    
    def __init__(self, config: RecipeConfig = None):
        self.config = config or RecipeConfig()
        self.session = requests.Session()
        
    def fetch_random_recipe(self) -> Optional[Dict]:
        """Récupère une recette aléatoire depuis TheMealDB"""
        try:
            url = f"{self.config.api_base_url}/random.php"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get('meals') and len(data['meals']) > 0:
                return data['meals'][0]
            return None
        except Exception as e:
            print(f"❌ Erreur lors de la récupération de recette: {e}")
            return None
    
    def fetch_recipe_by_id(self, meal_id: str) -> Optional[Dict]:
        """Récupère une recette spécifique par son ID"""
        try:
            url = f"{self.config.api_base_url}/lookup.php?i={meal_id}"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get('meals') and len(data['meals']) > 0:
                return data['meals'][0]
            return None
        except Exception as e:
            print(f"❌ Erreur lors de la récupération de la recette {meal_id}: {e}")
            return None
    
    def search_recipes_by_ingredient(self, ingredient: str) -> List[Dict]:
        """Recherche des recettes par ingrédient"""
        try:
            url = f"{self.config.api_base_url}/filter.php?i={ingredient}"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get('meals'):
                return data['meals']
            return []
        except Exception as e:
            print(f"❌ Erreur lors de la recherche par ingrédient: {e}")
            return []
    
    def translate_text(self, text: str, source_lang: str = "en", target_lang: str = "fr") -> str:
        """
        Traduit du texte en utilisant LibreTranslate (gratuit)
        
        Alternative: Vous pouvez utiliser Google Translate API, DeepL, ou autre
        """
        if not text or text.strip() == "":
            return text
        
        try:
            payload = {
                "q": text,
                "source": source_lang,
                "target": target_lang,
                "format": "text"
            }
            
            response = self.session.post(
                self.config.translate_api,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get('translatedText', text)
            else:
                print(f"⚠️ Traduction échouée (code {response.status_code}), texte original conservé")
                return text
                
        except Exception as e:
            print(f"⚠️ Erreur de traduction: {e}, texte original conservé")
            return text
    
    def translate_with_fallback(self, text: str) -> str:
        """Traduit avec un fallback manuel pour les termes courants"""
        # Dictionnaire de traductions manuelles pour les termes courants de cuisine
        manual_translations = {
            # Mesures
            "cup": "tasse",
            "cups": "tasses",
            "tablespoon": "cuillère à soupe",
            "tablespoons": "cuillères à soupe",
            "teaspoon": "cuillère à café",
            "teaspoons": "cuillères à café",
            "pound": "livre",
            "ounce": "once",
            "ounces": "onces",
            "clove": "gousse",
            "cloves": "gousses",
            "tin": "boîte",
            "can": "boîte",
            "sprinkling": "pincée",
            "pinch": "pincée",
            "leaves": "feuilles",
            "leaf": "feuille",
            
            # Ingrédients courants
            "olive oil": "huile d'olive",
            "garlic": "ail",
            "basil": "basilic",
            "salt": "sel",
            "pepper": "poivre",
            "onion": "oignon",
            "tomatoes": "tomates",
            "tomato": "tomate",
            "chicken": "poulet",
            "beef": "boeuf",
            "pork": "porc",
            "pasta": "pâtes",
            "cheese": "fromage",
            "milk": "lait",
            "butter": "beurre",
            "flour": "farine",
            "sugar": "sucre",
            "egg": "oeuf",
            "eggs": "oeufs",
        }
        
        # Essayer la traduction API d'abord
        translated = self.translate_text(text)
        
        # Si la traduction n'a pas changé le texte, essayer le dictionnaire manuel
        if translated.lower() == text.lower():
            for en, fr in manual_translations.items():
                translated = re.sub(
                    r'\b' + re.escape(en) + r'\b',
                    fr,
                    translated,
                    flags=re.IGNORECASE
                )
        
        return translated
    
    def extract_ingredients(self, meal: Dict) -> List[Dict]:
        """Extrait et structure les ingrédients d'une recette"""
        ingredients = []
        
        for i in range(1, 21):
            ingredient_key = f"strIngredient{i}"
            measure_key = f"strMeasure{i}"
            
            ingredient = meal.get(ingredient_key, "")
            measure = meal.get(measure_key, "")
            
            # Ignorer les ingrédients vides
            if not ingredient or ingredient.strip() == "":
                continue
            
            # Traduire l'ingrédient
            ingredient_fr = self.translate_with_fallback(ingredient)
            
            # Parser la mesure pour extraire quantité et unité
            quantity, unit = self.parse_measure(measure)
            
            ingredients.append({
                "nom": ingredient_fr.capitalize(),
                "quantite": quantity,
                "unite": unit
            })
        
        return ingredients
    
    def parse_measure(self, measure: str) -> tuple:
        """
        Parse une mesure pour extraire quantité et unité
        Exemple: "1/4 cup" -> (0.25, "tasse")
        """
        if not measure or measure.strip() == "":
            return (0, "")
        
        measure = measure.strip()
        
        # Traduire l'unité
        measure_fr = self.translate_with_fallback(measure)
        
        # Patterns pour extraire les nombres
        # Gérer les fractions (1/2, 1/4, etc.)
        fraction_pattern = r'(\d+)/(\d+)'
        # Gérer les nombres décimaux
        number_pattern = r'(\d+\.?\d*)'
        
        quantity = 0
        unit = measure_fr
        
        # Chercher les fractions
        fraction_match = re.search(fraction_pattern, measure)
        if fraction_match:
            numerator = float(fraction_match.group(1))
            denominator = float(fraction_match.group(2))
            quantity = numerator / denominator
            # Retirer la fraction de l'unité
            unit = re.sub(fraction_pattern, '', measure_fr).strip()
        
        # Chercher les nombres entiers ou décimaux
        number_match = re.search(number_pattern, measure)
        if number_match and quantity == 0:
            quantity = float(number_match.group(1))
            # Retirer le nombre de l'unité
            unit = re.sub(number_pattern, '', measure_fr).strip()
        
        return (quantity, unit)
    
    def split_instructions(self, instructions: str) -> List[str]:
        """Divise les instructions en étapes distinctes"""
        if not instructions:
            return []
        
        # Traduire les instructions
        instructions_fr = self.translate_text(instructions)
        
        # Diviser par retours à la ligne et points
        steps = []
        
        # D'abord diviser par \r\n ou \n
        lines = re.split(r'\r?\n', instructions_fr)
        
        for line in lines:
            # Diviser chaque ligne par les points suivis d'un espace
            sentences = re.split(r'\.\s+', line)
            for sentence in sentences:
                sentence = sentence.strip()
                # Garder seulement les phrases de plus de 10 caractères
                if len(sentence) > 10:
                    # Ajouter le point final s'il manque
                    if not sentence.endswith('.'):
                        sentence += '.'
                    steps.append(sentence)
        
        return steps
    
    def detect_type(self, category: str) -> str:
        """Détecte le type de plat à partir de la catégorie"""
        category = category.lower()
        
        type_mapping = {
            'dessert': 'dessert',
            'starter': 'entrée',
            'side': 'accompagnement',
            'breakfast': 'petit-déjeuner',
        }
        
        for key, value in type_mapping.items():
            if key in category:
                return value
        
        return 'plat'
    
    def generate_id(self, name: str) -> str:
        """Génère un ID à partir du nom de la recette"""
        # Convertir en minuscules
        id_str = name.lower()
        # Retirer les accents (optionnel, simplifie l'ID)
        id_str = re.sub(r'[àâä]', 'a', id_str)
        id_str = re.sub(r'[éèêë]', 'e', id_str)
        id_str = re.sub(r'[îï]', 'i', id_str)
        id_str = re.sub(r'[ôö]', 'o', id_str)
        id_str = re.sub(r'[ùûü]', 'u', id_str)
        id_str = re.sub(r'[ç]', 'c', id_str)
        # Remplacer espaces et caractères spéciaux par des tirets
        id_str = re.sub(r'[^a-z0-9]+', '-', id_str)
        # Retirer les tirets en début et fin
        id_str = id_str.strip('-')
        
        return id_str
    
    def estimate_cooking_times(self, instructions: str, ingredients_count: int) -> tuple:
        """
        Estime les temps de préparation et cuisson
        (approximation basée sur la complexité)
        """
        # Temps de base selon le nombre d'ingrédients
        prep_time = min(10 + (ingredients_count * 3), 45)
        
        # Rechercher des indices dans les instructions
        cook_keywords = {
            'bake': 30,
            'roast': 45,
            'simmer': 30,
            'boil': 20,
            'fry': 15,
            'grill': 20,
            'cook': 25
        }
        
        cook_time = 20  # Temps par défaut
        instructions_lower = instructions.lower()
        
        for keyword, time in cook_keywords.items():
            if keyword in instructions_lower:
                cook_time = max(cook_time, time)
        
        # Chercher des temps explicites dans les instructions (ex: "30 minutes")
        time_pattern = r'(\d+)\s*(minute|hour)'
        matches = re.findall(time_pattern, instructions_lower)
        
        if matches:
            total_time = 0
            for match in matches:
                value = int(match[0])
                unit = match[1]
                if unit == 'hour':
                    value *= 60
                total_time += value
            
            if total_time > 0:
                cook_time = total_time
        
        return (prep_time, cook_time)
    
    def transform_recipe(self, meal: Dict) -> Dict:
        """Transforme une recette TheMealDB au format souhaité"""
        
        print(f"📝 Traitement de: {meal['strMeal']}")
        
        # Traduire le nom
        nom_fr = self.translate_text(meal['strMeal'])
        
        # Générer l'ID
        recipe_id = self.generate_id(nom_fr)
        
        # Extraire les ingrédients
        ingredients = self.extract_ingredients(meal)
        
        # Diviser les instructions en étapes
        etapes = self.split_instructions(meal['strInstructions'])
        
        # Estimer les temps
        prep_time, cook_time = self.estimate_cooking_times(
            meal['strInstructions'],
            len(ingredients)
        )
        
        # Déterminer le type
        type_plat = self.detect_type(meal.get('strCategory', ''))
        
        # Construire la recette transformée
        transformed = {
            "id": recipe_id,
            "nom": nom_fr,
            "type": type_plat,
            "tempsPreparation": prep_time,
            "tempsCuisson": cook_time,
            "personnes": 4,  # TheMealDB ne fournit pas cette info
            "image": meal['strMealThumb'],
            "ingredients": ingredients,
            "etapes": etapes
        }
        
        return transformed
    
    def scrape_multiple(self, count: int = 10, delay: float = None) -> List[Dict]:
        """Récupère et transforme plusieurs recettes"""
        
        if delay is None:
            delay = self.config.delay_between_requests
        
        recipes = []
        processed_ids = set()
        
        print(f"\n🚀 Démarrage du scraping de {count} recettes...\n")
        
        attempts = 0
        max_attempts = count * 3  # Permettre quelques doublons
        
        while len(recipes) < count and attempts < max_attempts:
            attempts += 1
            
            # Récupérer une recette aléatoire
            meal = self.fetch_random_recipe()
            
            if not meal:
                print("⚠️ Aucune recette récupérée, nouvel essai...")
                time.sleep(delay)
                continue
            
            # Éviter les doublons
            meal_id = meal['idMeal']
            if meal_id in processed_ids:
                print(f"⏭️  Recette déjà traitée (ID: {meal_id}), passage à la suivante...")
                continue
            
            processed_ids.add(meal_id)
            
            try:
                # Transformer la recette
                transformed = self.transform_recipe(meal)
                recipes.append(transformed)
                
                print(f"✅ Recette {len(recipes)}/{count} ajoutée: {transformed['nom']}")
                print(f"   - {len(transformed['ingredients'])} ingrédients")
                print(f"   - {len(transformed['etapes'])} étapes")
                print()
                
                # Délai pour ne pas surcharger l'API
                if len(recipes) < count:
                    time.sleep(delay)
                    
            except Exception as e:
                print(f"❌ Erreur lors de la transformation: {e}")
                print()
                continue
        
        return recipes
    
    def save_to_json(self, recipes: List[Dict], output_file: str):
        """Sauvegarde les recettes dans un fichier JSON"""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(recipes, f, ensure_ascii=False, indent=2)
            print(f"\n💾 {len(recipes)} recettes sauvegardées dans: {output_file}")
        except Exception as e:
            print(f"❌ Erreur lors de la sauvegarde: {e}")


def main():
    """Fonction principale"""
    parser = argparse.ArgumentParser(
        description="Scraper de recettes TheMealDB avec traduction en français"
    )
    parser.add_argument(
        '--count',
        type=int,
        default=10,
        help='Nombre de recettes à récupérer (défaut: 10)'
    )
    parser.add_argument(
        '--output',
        type=str,
        default='recettes_fr.json',
        help='Fichier de sortie (défaut: recettes_fr.json)'
    )
    parser.add_argument(
        '--delay',
        type=float,
        default=1.0,
        help='Délai entre les requêtes en secondes (défaut: 1.0)'
    )
    
    args = parser.parse_args()
    
    # Créer le scraper
    config = RecipeConfig(delay_between_requests=args.delay)
    scraper = RecipeScraper(config)
    
    # Récupérer les recettes
    recipes = scraper.scrape_multiple(count=args.count, delay=args.delay)
    
    # Sauvegarder
    if recipes:
        scraper.save_to_json(recipes, args.output)
        print(f"\n✨ Terminé ! {len(recipes)} recettes ont été récupérées et traduites.")
    else:
        print("\n❌ Aucune recette n'a pu être récupérée.")


if __name__ == "__main__":
    main()

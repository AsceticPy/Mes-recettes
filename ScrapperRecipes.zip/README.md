# Recipe Scraper - TheMealDB vers Format Français

Script Python pour récupérer des recettes depuis TheMealDB, les traduire en français et les transformer dans votre format JSON personnalisé.

## 🚀 Installation

### Prérequis
- Python 3.7 ou supérieur
- pip

### Étapes

1. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

Ou directement :
```bash
pip install requests
```

## 📖 Utilisation

### Utilisation basique
Récupérer 10 recettes et les sauvegarder dans `recettes_fr.json` :
```bash
python recipe_scraper.py
```

### Options disponibles

#### Nombre de recettes
```bash
python recipe_scraper.py --count 20
```

#### Fichier de sortie personnalisé
```bash
python recipe_scraper.py --output mes_recettes.json
```

#### Délai entre les requêtes
Pour être gentil avec l'API et éviter les rate limits :
```bash
python recipe_scraper.py --delay 2.0
```

#### Combinaison d'options
```bash
python recipe_scraper.py --count 50 --output recettes_completes.json --delay 1.5
```

## 📋 Format de sortie

Le script transforme les recettes TheMealDB dans ce format :

```json
{
  "id": "penne-arrabiata-epicee",
  "nom": "Penne Arrabiata Épicée",
  "type": "plat",
  "tempsPreparation": 15,
  "tempsCuisson": 20,
  "personnes": 4,
  "image": "https://www.themealdb.com/images/media/meals/ustsqw1468250014.jpg",
  "ingredients": [
    {
      "nom": "Penne rigate",
      "quantite": 1,
      "unite": "livre"
    },
    {
      "nom": "Huile d'olive",
      "quantite": 0.25,
      "unite": "tasse"
    }
  ],
  "etapes": [
    "Porter une grande casserole d'eau à ébullition.",
    "Ajouter du sel casher à l'eau bouillante, puis ajouter les pâtes.",
    "Cuire selon les instructions de l'emballage, environ 9 minutes."
  ]
}
```

## 🔧 Fonctionnalités

### ✅ Ce que fait le script :

1. **Récupération depuis TheMealDB**
   - Récupère des recettes aléatoires
   - Évite les doublons automatiquement
   - Gère les erreurs réseau

2. **Traduction en français**
   - Utilise LibreTranslate (API gratuite)
   - Dictionnaire de fallback pour termes culinaires courants
   - Traduction du nom, ingrédients et instructions

3. **Transformation du format**
   - Génération d'ID depuis le nom français
   - Extraction et structuration des ingrédients
   - Parsing des quantités et unités
   - Division des instructions en étapes
   - Estimation des temps de préparation/cuisson
   - Détection du type de plat

4. **Optimisations**
   - Délai configurable entre requêtes
   - Gestion des rate limits
   - Journalisation en temps réel

## 🎯 Exemples d'utilisation avancée

### En tant que module Python

```python
from recipe_scraper import RecipeScraper, RecipeConfig

# Créer le scraper
config = RecipeConfig(delay_between_requests=2.0)
scraper = RecipeScraper(config)

# Récupérer une recette aléatoire
meal = scraper.fetch_random_recipe()
if meal:
    recipe = scraper.transform_recipe(meal)
    print(recipe)

# Récupérer plusieurs recettes
recipes = scraper.scrape_multiple(count=5)
scraper.save_to_json(recipes, 'mes_recettes.json')
```

### Recherche par ingrédient

Vous pouvez modifier le script pour rechercher des recettes spécifiques :

```python
# Rechercher des recettes avec du poulet
chicken_meals = scraper.search_recipes_by_ingredient('chicken')

# Récupérer les détails de chaque recette
for meal_preview in chicken_meals[:5]:
    meal = scraper.fetch_recipe_by_id(meal_preview['idMeal'])
    recipe = scraper.transform_recipe(meal)
    print(recipe['nom'])
```

## ⚙️ Configuration avancée

### Changer l'API de traduction

Par défaut, le script utilise LibreTranslate (gratuit mais peut être lent). Vous pouvez utiliser d'autres services :

#### Google Translate API (payant mais précis)
```python
# Modifier la méthode translate_text dans RecipeScraper
from googletrans import Translator

def translate_text(self, text, source_lang="en", target_lang="fr"):
    translator = Translator()
    result = translator.translate(text, src=source_lang, dest=target_lang)
    return result.text
```

#### DeepL API (excellent pour les traductions)
```python
import deepl

def translate_text(self, text, source_lang="en", target_lang="fr"):
    translator = deepl.Translator("YOUR_AUTH_KEY")
    result = translator.translate_text(text, source_lang="EN", target_lang="FR")
    return result.text
```

### Sans traduction automatique

Si vous préférez une approche purement basée sur le dictionnaire manuel (plus rapide mais moins précise) :

```python
# Commenter l'appel à translate_text dans translate_with_fallback
def translate_with_fallback(self, text: str) -> str:
    translated = text  # Pas de traduction API
    
    # Uniquement le dictionnaire manuel
    for en, fr in manual_translations.items():
        translated = re.sub(...)
    
    return translated
```

## 🐛 Résolution de problèmes

### Erreur "Connection timeout"
- Augmentez le délai : `--delay 3.0`
- Vérifiez votre connexion internet

### Traductions incorrectes
- LibreTranslate est gratuit mais parfois imprécis
- Envisagez d'utiliser Google Translate ou DeepL (voir Configuration avancée)
- Enrichissez le dictionnaire manuel dans le code

### Trop lent
- Réduisez le délai (risque de rate limit) : `--delay 0.5`
- Désactivez la traduction API (voir Configuration avancée)
- Récupérez moins de recettes à la fois

### API LibreTranslate indisponible
Si l'API publique de LibreTranslate est hors ligne :

1. **Installer votre propre instance**
```bash
docker run -ti --rm -p 5000:5000 libretranslate/libretranslate
```

2. **Modifier l'URL dans le script**
```python
config = RecipeConfig()
config.translate_api = "http://localhost:5000/translate"
```

## 📊 Statistiques

Le script affiche en temps réel :
- Nombre de recettes traitées
- Nom de chaque recette
- Nombre d'ingrédients et d'étapes
- Progression globale

Exemple de sortie :
```
🚀 Démarrage du scraping de 10 recettes...

📝 Traitement de: Spicy Arrabiata Penne
✅ Recette 1/10 ajoutée: Penne Arrabiata Épicée
   - 8 ingrédients
   - 6 étapes

📝 Traitement de: Beef Bourguignon
✅ Recette 2/10 ajoutée: Bœuf Bourguignon
   - 12 ingrédients
   - 8 étapes

...

💾 10 recettes sauvegardées dans: recettes_fr.json

✨ Terminé ! 10 recettes ont été récupérées et traduites.
```

## 📝 Notes importantes

### Limitations de TheMealDB
- Base de données de ~600 recettes
- Principalement recettes anglophones
- Pas d'informations sur le nombre de personnes
- Temps de cuisson souvent estimés

### Respect de l'API
- Utilisez un délai raisonnable (>=1 seconde)
- N'abusez pas des requêtes
- Pour usage commercial, considérez le Patreon ($2/mois)

### Qualité de la traduction
- LibreTranslate : gratuit mais basique
- Pour meilleure qualité : Google Translate ou DeepL
- Le dictionnaire manuel aide pour les termes courants

## 🔗 Ressources

- [TheMealDB API Documentation](https://www.themealdb.com/api.php)
- [LibreTranslate](https://libretranslate.com/)
- [Documentation Python requests](https://requests.readthedocs.io/)

## 📄 Licence

Ce script est fourni tel quel pour usage personnel et éducatif.
Respectez les conditions d'utilisation de TheMealDB pour usage commercial.

## 🤝 Contributions

Améliorations bienvenues :
- Meilleure estimation des temps de cuisson
- Support d'autres APIs de recettes
- Amélioration de la traduction
- Tests unitaires

## 💡 Astuces

### Récupérer uniquement des recettes d'une catégorie

Modifiez le script pour filtrer :

```python
def scrape_category(self, category: str, count: int = 10):
    """Récupère des recettes d'une catégorie spécifique"""
    url = f"{self.config.api_base_url}/filter.php?c={category}"
    response = self.session.get(url)
    meals = response.json().get('meals', [])
    
    recipes = []
    for meal_preview in meals[:count]:
        meal = self.fetch_recipe_by_id(meal_preview['idMeal'])
        if meal:
            recipes.append(self.transform_recipe(meal))
            time.sleep(self.config.delay_between_requests)
    
    return recipes

# Utilisation
recipes = scraper.scrape_category('Dessert', count=10)
```

### Sauvegarder aussi les images localement

```python
import os
from urllib.request import urlretrieve

def download_image(self, url: str, recipe_id: str) -> str:
    """Télécharge l'image de la recette localement"""
    os.makedirs('images', exist_ok=True)
    
    extension = url.split('.')[-1]
    filename = f"images/{recipe_id}.{extension}"
    
    try:
        urlretrieve(url, filename)
        return filename
    except:
        return url

# Dans transform_recipe, remplacer :
"image": self.download_image(meal['strMealThumb'], recipe_id)
```

## 🎓 Exemple complet

```bash
# 1. Installation
pip install requests

# 2. Récupération de 30 recettes
python recipe_scraper.py --count 30 --output recettes_base.json --delay 1.5

# 3. Le fichier recettes_base.json contient maintenant 30 recettes françaises
#    prêtes à être utilisées dans votre application !
```

Bon scraping ! 🚀
